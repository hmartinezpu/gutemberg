import "./boxes";
import "./menu";
import "./galeria";
import "./hero";
import "./textoimagen";
import "./contenedor";