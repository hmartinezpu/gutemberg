jQuery(document).ready( $ => {
    // Menu responsive
    $('#menu ul').slicknav({
        appendTo: $('.site-header')
    });
});