<aside class="sidebar">
    <?php 
        if( is_active_sidebar('blog_sidebar') ):
            dynamic_sidebar('blog_sidebar');
        endif;
    ?>
</aside>